import React from 'react';

class Footer extends React.Component {
    render() {
       return (
          <div>
             <h2>Footer</h2>
          </div>
       );
    }
 }
 export default Footer;