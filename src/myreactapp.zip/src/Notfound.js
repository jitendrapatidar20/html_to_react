import React from 'react'  
const Notfound = () => <h1>Not found</h1>  
export default Notfound  