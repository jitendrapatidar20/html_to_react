import React,{useEffect,useState} from 'react';
import Header from './Header';
import Footer from './Footer';
import MyForm from './MyForm';

import './App.css';

class Contact extends React.Component {  
  render() {  
    return (
        <div className="App">
        <Header/>
        <MyForm/>
        <Footer/>
        </div>
    );
  }  
}  
export default Contact  